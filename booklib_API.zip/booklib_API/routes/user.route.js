var express = require("express");
var router = express.Router();
var users = require("../models/user.model");

router.get("/getuser", function(req, res) {
  var userId = req.query.userid;
  users.find({'UserId': userId}, function(err, response) {
    if (response.length > 0) {
      res.send(response);
    } else {
      res.send("no data");
    }
  });
});

module.exports = router;
