import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TasksComponent } from './tasks/tasks.component';
import { Routes, RouterModule } from '@angular/router';
import { BooksComponent } from './books/books.component';
import { BookDetailsComponent } from './book-details/book-details.component';



const routes: Routes = [
  {
    path: '',
    component: TasksComponent
  },
  {
    path: 'book',
    component: BooksComponent
  },
  {
    path: 'book/bookdetails',
    component: BookDetailsComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
