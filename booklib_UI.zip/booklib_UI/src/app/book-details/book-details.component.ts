import { Component, OnInit } from '@angular/core';
import { TaskserviceService } from '../../services/api.service';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  public isbn: any;
  public details: any;
  constructor(private taskservice: TaskserviceService) { }

  ngOnInit() {
    this.isbn = localStorage.getItem('isbn');
    this.fetchBookDetails(this.isbn);
  }
  fetchBookDetails(isbn) {
    this.taskservice.getBookDetails(isbn)
    .subscribe((res) => {
      if (res != null && res !== undefined) {
        this.details = res.items[0];
        console.log('details' + this.details);
      }
      return false;
    }, (err) => {
      throw err;
    });
  }
}
